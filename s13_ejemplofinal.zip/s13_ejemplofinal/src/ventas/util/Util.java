/*
 * 
 */
package ventas.util;

/**
 *
 * @author Emaravi
 */
public class Util {
    public static final int STM=0;
    public static final int PST=1;
    public static final int CST=2;
    
    public static int opc=0;
}
